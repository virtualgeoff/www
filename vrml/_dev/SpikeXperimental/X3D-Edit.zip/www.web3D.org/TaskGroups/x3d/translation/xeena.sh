#!/bin/ksh

echo running xeena.sh ...

# ----------------------------------------------------------------------
# Korn shell script
# Run Xeena
#
# Xeena is brought to you by the IBM Haifa Research Lab, Israel
# Please send feedback to helpmap@il.ibm.com
# (C) 1999-2000 IBM Corporation. All rights reserved.
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# To specify a proxy, change the following line to something like this:
# set PROXY_SETTINGS="-DproxySet=true -DproxyHost=proxy.host.name -DproxyPort=port
# ----------------------------------------------------------------------
PROXY_SETTINGS="-DproxySet=false"
export PROXY_SETTINGS

# ----------------------------------------------------------------------
# Determine JAVA_HOME where JDK is installed
# ----------------------------------------------------------------------
if [ "X" = "X$JAVA_HOME" ]
then
    echo Error:
    echo Environment variable JAVA_HOME has not been set.
    echo XEENA needs to know where JDK or JRE is installed in your host.
    echo Please set JAVA_HOME to the full path name of the root directory
    echo where JDK or JRE is installed. For example, you can set JAVA_HOME
    echo in a korn shell by the following commands:
    echo "   JAVA_HOME=/usr/jdk1.1.6"
    echo "   export JAVA_HOME"
    echo when JDK is installed in directory /usr/jdk1.1.6.
    exit
fi
echo using java in 	[$JAVA_HOME]

# To run Xeena using JDK 1.2, replace the following line with:
# "$JAVA_HOME/bin/java.exe" -Xmx100m -Xms30m -Dfile.path.casesensitive=true -Dswing.defaultlaf=com.sun.java.swing.plaf.motif.MotifLookAndFeel $PROXY_SETTINGS com.ibm.hrl.xmleditor.CXMLEditor $*

CLASSPATH=lib/xmleditor.jar:lib/xml4j.jar:lib/jgl3.1.0.jar:lib/lotusxsl.jar:lib/swingall.jar
if [ "X" != "X$BML_HOME" ]
    then CLASSPATH=$CLASSPATH:$BML_HOME:$BML_HOME/lib/bmlall.jar
fi

"$JAVA_HOME/bin/java" -mx100m -ms30m -Dfile.path.casesensitive=true -Dswing.defaultlaf=com.sun.java.swing.plaf.motif.MotifLookAndFeel -cp $CLASSPATH $PROXY_SETTINGS com.ibm.hrl.xmleditor.CXMLEditor $*


