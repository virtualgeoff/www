From:     steve guynup <guynups@gra.com>     Fri November 13 1999, 7:23 AM
Subject: Re: [www-vrml] announce: X3D-Edit
To: Don Brutzman <brutzman@nps.navy.mil>
CC: mac-vrml-x3d@egroups.com

Hello Folks

X3D seems to be off to a good start on the Mac.  Just wanted to report that
the Xeena editor with X3D does run on the Mac.  This is in addition to both
Shout's and Blaxxun's proposals being Mac compatible...

More help available at http://www.MacWeb3D.org/

for those who wish to try it now...

Download and install the MRJ Java 2.2 early access 2
and the SDK 2.2 early access 2
http://developer.apple.com/java/index.html

(you "may" need Disk Copy to install)
http://www.macupdate.com/info/33094.html

then go to

Boris's Site - he has great instructions on Xeena (only)
http://gulf.uvic.ca/~bmann/maconjava/howtorun/index.html
he's got screen grabs!!!
http://gulf.uvic.ca/~bmann/maconjava/howtorun/xeena/screenshots/index.html

follow his instructions:
and here's two added tips that would have saved me a  bit of trouble

Don't place Xeena in a folder with a space in its name, this includes
"Desktop Folder"

You'll need Stuffit Expander and check your preferences!
        under expanding - continue to expand - un-check this
        under cross platform - covert to mac format - select never

and when installing Xeena,
in the command window - optional properties

-dtd latest-brutzman.dtd
-root X3D
-xml AllVrml97Nodes.xml

[...original README has more details...]

        http://www.MacWeb3D.org/
        http://leper.to
============================================================

    "Where are the blinding insights of yesteryear? Around me I see
      nothing but groundless hysteria and unscrupulous vitality"
                                 --Baudrillard, 1990
