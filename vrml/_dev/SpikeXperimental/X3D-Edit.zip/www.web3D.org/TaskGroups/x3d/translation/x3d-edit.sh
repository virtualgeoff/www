#!/bin/csh
source /IBM/Xeena/xeena.sh -root X3D -dtd www.web3D.org/TaskGroups/x3d/translation/x3d-compromise.dtd

